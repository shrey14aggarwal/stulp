package de.upb.STULP.json;

public enum Tag {
    Mo, Di, Mi, Do, Fr, Sa, So
}
