package de.upb.STULP.json;

/**
 * An enum for possible commands.
 *
 */
public enum Cmd {
	insert, insert_pflicht
}
