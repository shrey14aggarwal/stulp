package de.upb.STULP.JsonParser;

import java.util.List;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import de.upb.STULP.json.Command;

/**
 * This class is simple example for using the Gson library to implement json conversion.
 *
 * 
 */
public class JsonConversion
{
    /**
     * Remember to use the short forms for days.
     * Namely: Mo, Di, Mi, Do, Fr, Sa, So
     */

    
    public static List<Command> deserialise_JSON(String s)
    {
        Gson gson = new Gson();
        return gson.fromJson(s, new TypeToken<List<Command>>(){}.getType());
    }
}
