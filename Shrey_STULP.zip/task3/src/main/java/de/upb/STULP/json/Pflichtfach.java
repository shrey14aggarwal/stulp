package de.upb.STULP.json;

public enum Pflichtfach {
    ja, nein
}
