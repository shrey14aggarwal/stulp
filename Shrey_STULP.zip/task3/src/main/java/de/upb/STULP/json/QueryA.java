package de.upb.STULP.json;

/**
 * This class holds the results of Query A
 * 
 * @author shrey
 *
 */
public class QueryA {

	String kursID, studiengangsID;

	/**
	 * @param kursID         sets the kursID value
	 * @param studiengangsID sets the studiengangsID value
	 */
	public QueryA(String kursID, String studiengangsID) {
		this.kursID = kursID;
		this.studiengangsID = studiengangsID;
	}

	/**
	 * 
	 * @return kursID
	 */
	public String getKursID() {
		return kursID;
	}

	/**
	 * 
	 * @param kursID sets the kursID value
	 */
	public void setKursID(String kursID) {
		this.kursID = kursID;
	}

	/**
	 * 
	 * @return studiengangsID
	 */
	public String getStudiengangsID() {
		return studiengangsID;
	}

	/**
	 * @param studiengangsID sets the studiengangsID value
	 */
	public void setStudiengangsID(String studiengangsID) {
		this.studiengangsID = studiengangsID;
	}

}
