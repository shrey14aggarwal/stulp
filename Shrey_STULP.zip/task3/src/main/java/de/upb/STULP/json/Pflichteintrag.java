package de.upb.STULP.json;

/**
 * Represents an entry in the Pflicht table.
 * 
 * 
 */
public class Pflichteintrag {

	private String kursID, studiengangsID, kursname, alternativgruppe;
	private Pflichtfach pflichtfach;
	private int veranstaltungsteil;

	public Pflichteintrag(String kursID, String studiengangsID, String kursname, Pflichtfach pflichtfach,
			String alternativgruppe, int veranstaltungsteil) {
		this.kursID = kursID;
		this.studiengangsID = studiengangsID;
		this.kursname = kursname;
		this.pflichtfach = pflichtfach;
		this.alternativgruppe = alternativgruppe;
		this.veranstaltungsteil = veranstaltungsteil;
	}

	public String getKursID() {
		return kursID;
	}

	public void setKursID(String kursID) {
		this.kursID = kursID;
	}

	public String getStudiengangsID() {
		return studiengangsID;
	}

	public void setStudiengangsID(String studiengangsID) {
		this.studiengangsID = studiengangsID;
	}

	public String getKursname() {
		return kursname;
	}

	public void setKursname(String kursname) {
		this.kursname = kursname;
	}

	public Pflichtfach getPflichtfach() {
		return pflichtfach;
	}

	public void setPflichtfach(Pflichtfach pflichtfach) {
		this.pflichtfach = pflichtfach;
	}

	public String getAlternativgruppe() {
		return alternativgruppe;
	}

	public void setAlternativgruppe(String alternativgruppe) {
		this.alternativgruppe = alternativgruppe;
	}

	public int getVeranstaltungsteil() {
		return veranstaltungsteil;
	}

	public void setVeranstaltungsteil(int veranstaltungsteil) {
		this.veranstaltungsteil = veranstaltungsteil;

	}

}
