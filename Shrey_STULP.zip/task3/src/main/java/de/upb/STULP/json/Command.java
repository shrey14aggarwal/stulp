package de.upb.STULP.json;

/**
 * This class represents a command of the input command list.
 * 
 */
public final class Command {

	private Cmd cmd;
	private Veranstaltungseintrag veranstaltungseintrag;
	private Pflichteintrag pflichteintrag;

	public Command(Cmd cmd, Pflichteintrag pflichteintrag) {
		this.cmd = cmd;
		this.pflichteintrag = pflichteintrag;
	}

	public Command(Cmd cmd, Veranstaltungseintrag veranstaltungseintrag) {
		this.cmd = cmd;
		this.veranstaltungseintrag = veranstaltungseintrag;
	}

	/**
	 * @return the cmd
	 */
	public Cmd getCmd() {
		return cmd;
	}

	/**
	 * @param cmd the cmd to set
	 */
	public void setCmd(Cmd cmd) {
		this.cmd = cmd;
	}

	/**
	 * @return the veranstaltungseintrag
	 */
	public Veranstaltungseintrag getVeranstaltungseintrag() {
		return veranstaltungseintrag;
	}

	/**
	 * @param veranstaltungseintrag the veranstaltungseintrag to set
	 */
	public void setVeranstaltungseintrag(Veranstaltungseintrag veranstaltungseintrag) {
		this.veranstaltungseintrag = veranstaltungseintrag;
	}

	/**
	 * 
	 * @return pflichteintrag
	 */
	public Pflichteintrag getPflichteintrag() {
		return pflichteintrag;
	}

	/**
	 * 
	 * @param pflichteintrag
	 */
	public void setPflichteintrag(Pflichteintrag pflichteintrag) {
		this.pflichteintrag = pflichteintrag;
	}

}
