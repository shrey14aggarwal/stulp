package de.upb.STULP.json;

/**
 * This class holds the results of Query B
 * 
 * @author shrey
 *
 */
public class QueryB {

	String kursID1, kursID2, studiengangsID;

	public QueryB(String kursID1, String kursID2, String studiengangsID) {
		this.kursID1 = kursID1;
		this.kursID2 = kursID2;
		this.studiengangsID = studiengangsID;
	}

	/**
	 * 
	 * @return kursID1
	 */
	public String getKursID1() {
		return kursID1;
	}

	/**
	 * 
	 * @param kursID1 sets the value of kursID1
	 */
	public void setKursID1(String kursID1) {
		this.kursID1 = kursID1;
	}

	/**
	 * 
	 * @return kursID2
	 */
	public String getKursID2() {
		return kursID2;
	}

	/**
	 * 
	 * @param kursID2 sets the value of kursID2
	 */
	public void setKursID2(String kursID2) {
		this.kursID2 = kursID2;
	}

	/**
	 * 
	 * @return studiengangsID
	 */
	public String getStudiengangsID() {
		return studiengangsID;
	}

	/**
	 * 
	 * @param studiengangsID sets the value of studiengangsID
	 */
	public void setStudiengangsID(String studiengangsID) {
		this.studiengangsID = studiengangsID;
	}

}
