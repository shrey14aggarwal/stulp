package de.upb.STULP.json;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * This class handles the operations related to the Pflicht table
 * 
 * @author shrey
 *
 */
public class Operations_pflicht {

	Connection conn;

	/**
	 * This method creates the Pflicht table
	 * 
	 * @param conn is the database connection
	 * @throws SQLException
	 */
	public void create_table_pflicht(Connection conn) throws SQLException {

		PreparedStatement stmt;

		String query2 = "create table if not exists Pflicht (kursID TEXT not null," + "veranstaltungsteil int not null,"
				+ "studiengangsID text not null," + "kursname TEXT not null," + "pflichtfach TEXT not null,"
				+ "alternativgruppe TEXT not null," + "PRIMARY KEY (kursID, veranstaltungsteil, studiengangsID), "
				+ "FOREIGN KEY (kursID, veranstaltungsteil) REFERENCES Veranstaltungsplan(kursID, veranstaltungsteil)"
				+ ")";

		stmt = conn.prepareStatement(query2);
		stmt.executeUpdate();
		stmt.close();

	}

	/**
	 * This method clears the Pflicht table
	 * 
	 * @param conn is the database connection
	 * @throws SQLException
	 */
	public void clear_table_pflicht(Connection conn) throws SQLException {
		PreparedStatement stmt;

		String query2 = "delete from Pflicht";

		stmt = conn.prepareStatement(query2);
		stmt.executeUpdate();
		stmt.close();

	}

	/**
	 * This method inserts the records in Pflicht table
	 * 
	 * @param conn is the database connection
	 * @param p    refers to the pflichteintrag in Command list
	 * @throws SQLException
	 */
	public void insert_pflicht(Connection conn, Pflichteintrag p) throws SQLException {
		PreparedStatement stmt;

		String query = "insert into Pflicht values (?,?,?,?,?,?)";
		stmt = conn.prepareStatement(query);

		stmt.setString(1, p.getKursID());
		stmt.setInt(2, p.getVeranstaltungsteil());
		stmt.setString(3, p.getStudiengangsID());
		stmt.setString(4, p.getKursname());
		stmt.setString(5, p.getPflichtfach().name());
		stmt.setString(6, p.getAlternativgruppe());

		stmt.executeUpdate();
		stmt.close();

	}

}
