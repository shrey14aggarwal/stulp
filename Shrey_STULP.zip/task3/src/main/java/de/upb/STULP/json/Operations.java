package de.upb.STULP.json;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * This class handles the operations related to Veranstaltungsplan table and also
 * checks the desired conflicts
 * 
 * @author shrey
 *
 */
public class Operations {

	/**
	 * This method creates the database connection
	 * @return conn is the database connection
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public Connection database_Connection() throws ClassNotFoundException, SQLException {
		Connection conn;
		conn = DriverManager.getConnection("jdbc:sqlite:shreystulp.db");
		return conn;
	}

	/**
	 * This method creates the Veranstaltungsplan table
	 * 
	 * @param conn is the database connection
	 * @throws SQLException
	 */
	public void create_table_Veranstaltungsplan(Connection conn) throws SQLException {
		PreparedStatement stmt;
		String query1 = "create table IF NOT EXISTS Veranstaltungsplan (" + "raumNr TEXT not null,"
				+ "profID TEXT not null," + "kursID TEXT not null," + "veranstaltungsteil int not null,"
				+ "veranstaltungart TEXT not null," + "dauer int not null," + "tag TEXT not null,"
				+ "uhrzeit int not null," + "wunschzeit int not null," + "PRIMARY KEY (kursID, veranstaltungsteil))";

		stmt = conn.prepareStatement(query1);
		stmt.executeUpdate();

		stmt.close();
	}

	/**
	 * This method clears the Veranstaltungsplan table
	 * 
	 * @param conn is the database connection
	 * @throws SQLException
	 */
	public void clear_table_Veranstaltungsplan(Connection conn) throws SQLException {
		PreparedStatement stmt;
		String query2 = "delete from Veranstaltungsplan";
		stmt = conn.prepareStatement(query2);
		stmt.executeUpdate();

	}

	/**
	 * This method drops the already created view for the table of query B
	 * 
	 * @param conn is the database connection
	 * @throws SQLException
	 */
	public void drop_view(Connection conn) throws SQLException {
		PreparedStatement stmt;
		String query2 = "drop view if exists view1";
		stmt = conn.prepareStatement(query2);
		stmt.executeUpdate();

	}

	/**
	 * 
	 * @param conn is the database connection
	 * @param ver  refers to the Veranstaltungseintrag in the Command list
	 * @throws SQLException
	 */
	public void insert_Veranstaltungsplan(Connection conn, Veranstaltungseintrag ver) throws SQLException {
		PreparedStatement stmt;

		// query to insert a record in the table
		String query = "insert into Veranstaltungsplan values(?,?,?,?,?,?,?,?,?)";
		stmt = conn.prepareStatement(query);
		stmt.setString(1, ver.getRaumNr());
		stmt.setString(2, ver.getProfID());
		stmt.setString(3, ver.getKursID());
		stmt.setInt(4, ver.getVeranstaltungsteil());
		stmt.setString(5, ver.getVeranstaltungart());
		stmt.setInt(6, ver.getDauer());
		stmt.setString(7, ver.getTag().name());
		stmt.setInt(8, ver.getUhrzeit());
		stmt.setInt(9, ver.getWunschzeit());

		stmt.executeUpdate();
		stmt.close();
	}

	/**
	 * This method checks the desired conflicts
	 * 
	 * @param conn is the database connection
	 * @throws SQLException
	 * @throws IOException
	 */
	public void showConflict(Connection conn) throws SQLException, IOException {

		// Lists to store the results of Query A and Query B
		ArrayList<QueryA> listA = new ArrayList();
		ArrayList<QueryB> listB = new ArrayList();

		// Query A
		String query1 =
				// This part returns the results whose atleast 1 �bung overlaps
				// with either the Vorlesung or Zentral�bung of other kurs
				"select distinct v1.kursID, p1.studiengangsID "
						+ "from Veranstaltungsplan v1, Veranstaltungsplan v2, Pflicht p1, Pflicht p2 "
						+ "where p1.studiengangsID=p2.studiengangsID and v1.kursID=p1.kursID and v1.veranstaltungsteil=p1.veranstaltungsteil and "
						+ "v2.kursID=p2.kursID and v2.veranstaltungsteil=p2.veranstaltungsteil and "
						+ "v1.tag=v2.tag and (v1.uhrzeit<v2.uhrzeit+(v2.dauer) AND v1.uhrzeit+(v1.dauer)>v2.uhrzeit) and ((v1.veranstaltungsteil <> v2.veranstaltungsteil) or "
						+ "(v1.kursID <> v2.kursID)) "
						+ "and v1.veranstaltungsteil  <> 1 and (v2.veranstaltungart='Vorlesung' or v2.veranstaltungart='Zentral�bung')   and p2.pflichtfach = 'ja' "
						+ "except "
						// This part removes those results whose pflichtfach of Vorlesung is nein
						+ "select v1.kursID,p1.studiengangsID from "
						+ "Veranstaltungsplan v1, Pflicht p1, Veranstaltungsplan v2, Pflicht p2 "
						+ "where v1.kursID=p1.kursID and v2.kursID=p2.kursID and "
						+ "v1.veranstaltungsteil=p1.veranstaltungsteil and v2.veranstaltungsteil=p2.veranstaltungsteil and "
						+ "p1.studiengangsID=p2.studiengangsID and v1.veranstaltungart='�bung' and "
						+ "v2.veranstaltungart='Vorlesung' and p2.pflichtfach='nein' and v1.kursID=v2.kursID "
						// This whole group returns those results whose atleast 1 �bung does not
						// overlap with either Vorlesung or Zentral�bung of any other kurs
						+ "except " + "select distinct v3.kursID, v3.studiengangsID from ( "
						+ "select distinct v1.kursID,v1.veranstaltungsteil, p1.studiengangsID from Veranstaltungsplan v1, Veranstaltungsplan v2, Pflicht p1 , Pflicht p2 "
						+ "where v1.kursID <> v2.kursID and (v1.tag <> v2.tag or (v1.uhrzeit>=v2.uhrzeit+(v2.dauer) OR v1.uhrzeit+(v1.dauer)<=v2.uhrzeit)) "
						+ "and v1.veranstaltungsteil <> v2.veranstaltungsteil "
						+ "and (v2.veranstaltungart='Vorlesung' or  v2.veranstaltungart='Zentral�bung') "
						+ "and v1.kursID=p1.kursID and v1.veranstaltungsteil=p1.veranstaltungsteil and v2.kursID=p2.kursID and v2.veranstaltungsteil=p2.veranstaltungsteil "
						+ "and v1.veranstaltungart = '�bung' and p2.pflichtfach='ja' and p1.studiengangsID=p2.studiengangsID "
						+ "except " + "select  distinct v1.kursID,v1.veranstaltungsteil, p1.studiengangsID "
						+ "from Veranstaltungsplan v1, Veranstaltungsplan v2 , Pflicht p1, Pflicht p2 " + "where "
						+ "p1.studiengangsID=p2.studiengangsID and v1.kursID=p1.kursID and v1.veranstaltungsteil=p1.veranstaltungsteil and "
						+ "v2.kursID=p2.kursID and v2.veranstaltungsteil=p2.veranstaltungsteil " + "and "
						+ "v1.tag=v2.tag and (v1.uhrzeit<v2.uhrzeit+v2.dauer AND v1.uhrzeit+v1.dauer>v2.uhrzeit) and ((v1.veranstaltungsteil <> v2.veranstaltungsteil) or "
						+ "(v1.kursID <> v2.kursID)) "
						+ "and  v1.veranstaltungsteil  <> 1  and v1.kursID=p1.kursID and v1.veranstaltungsteil=p1.veranstaltungsteil and p2.pflichtfach = 'ja' "
						+ "and (v2.veranstaltungart='Vorlesung' or v2.veranstaltungart='Zentral�bung') " + " ) v3 ";

		Statement stmt = conn.createStatement();

		ResultSet rs = stmt.executeQuery(query1);

		System.out.println("The output of query A is \n");
		System.out.println("kursID" + "   " + "studiengangsID");

		while (rs.next()) {

			String kursID = rs.getString(1);
			String studiengangsID = rs.getString(2);

			// Adding the results of query A to the list of type QueryA
			QueryA queryA = new QueryA(kursID, studiengangsID);
			listA.add(queryA);

			System.out.println(kursID + "       " + studiengangsID);

		}

		// This is query B to check the other conflict
		String query2 = "create view view1 as "

				// This part returns those results whose �bung overlaps with
				// atleast 1 other component of other kurs
				+ " select  v1.kursID, p1.studiengangsID "
				+ "from Veranstaltungsplan v1, Veranstaltungsplan v2, Pflicht p1, Pflicht p2 "
				+ "where p1.studiengangsID=p2.studiengangsID and v1.kursID=p1.kursID and v1.veranstaltungsteil=p1.veranstaltungsteil and "
				+ "v2.kursID=p2.kursID and v2.veranstaltungsteil=p2.veranstaltungsteil and "
				+ "v1.tag=v2.tag and (v1.uhrzeit<v2.uhrzeit+(v2.dauer) AND v1.uhrzeit+(v1.dauer)>v2.uhrzeit) and ((v1.veranstaltungsteil <> v2.veranstaltungsteil) or "
				+ "(v1.kursID <> v2.kursID)) " + "and v1.veranstaltungsteil  <> 1 "
				// This part removes those results whose pflichtfach for vorlesung is nein
				+ "except " + "select v1.kursID,p1.studiengangsID from "
				+ "Veranstaltungsplan v1, Pflicht p1, Veranstaltungsplan v2, Pflicht p2 "
				+ "where v1.kursID=p1.kursID and v2.kursID=p2.kursID and "
				+ "v1.veranstaltungsteil=p1.veranstaltungsteil and v2.veranstaltungsteil=p2.veranstaltungsteil and "
				+ "p1.studiengangsID=p2.studiengangsID and v1.veranstaltungart='�bung' and "
				+ "v2.veranstaltungart='Vorlesung' and (p2.pflichtfach='nein' or p2.pflichtfach=null) and v1.kursID=v2.kursID "
				// This whole group returns those results whose atleast 1 �bung does not
				// overlap with either of the components of other required kurs
				+ "except " + "select distinct v3.kursID, v3.studiengangsID from ( "
				+ "select distinct v1.kursID,v1.veranstaltungsteil, p1.studiengangsID from Veranstaltungsplan v1, Veranstaltungsplan v2, Pflicht p1 , Pflicht p2 "
				+ "where v1.kursID <> v2.kursID and (v1.tag <> v2.tag or (v1.uhrzeit>=v2.uhrzeit+(v2.dauer) OR v1.uhrzeit+(v1.dauer)<=v2.uhrzeit)) "
				+ "and v1.veranstaltungsteil <> v2.veranstaltungsteil  "
				+ "and v1.kursID=p1.kursID and v1.veranstaltungsteil=p1.veranstaltungsteil "
				+ "and v2.kursID=p2.kursID and v2.veranstaltungsteil=p2.veranstaltungsteil "
				+ "and v1.veranstaltungart = '�bung' " + "and p1.studiengangsID=p2.studiengangsID " + "except "
				+ "select  distinct v1.kursID,v1.veranstaltungsteil, p1.studiengangsID "
				+ "from Veranstaltungsplan v1, Veranstaltungsplan v2 , Pflicht p1, Pflicht p2 " + "where "
				+ "p1.studiengangsID=p2.studiengangsID and v1.kursID=p1.kursID and v1.veranstaltungsteil=p1.veranstaltungsteil and "
				+ "v2.kursID=p2.kursID and v2.veranstaltungsteil=p2.veranstaltungsteil " + "and "
				+ "v1.tag=v2.tag and (v1.uhrzeit<v2.uhrzeit+v2.dauer AND v1.uhrzeit+v1.dauer>v2.uhrzeit) and ((v1.veranstaltungsteil <> v2.veranstaltungsteil) or  "
				+ "(v1.kursID <> v2.kursID)) "
				+ " and  v1.veranstaltungsteil  <> 1  and v1.kursID=p1.kursID and v1.veranstaltungsteil=p1.veranstaltungsteil "
				+ " ) v3";

		stmt = conn.createStatement();

		stmt.executeUpdate(query2);

		// This query fetches the results from the view created
		String query3 = "select distinct v1.kursID, v2.kursID, v1.studiengangsID from view1 v1, view1 v2 where v1.kursID <>v2.kursID "
				+ "and v1.studiengangsID=v2.studiengangsID";

		stmt = conn.createStatement();

		rs = stmt.executeQuery(query3);

		while (rs.next()) {

			String kursID1, kursID2, studiengangsID;

			kursID1 = rs.getString(1);
			kursID2 = rs.getString(2);
			studiengangsID = rs.getString(3);

			// Adding the results of query B to the list of type Query B
			QueryB l = new QueryB(kursID1, kursID2, studiengangsID);
			listB.add(l);

		}

		System.out.println("\n\n************************************************************************\n");
		System.out.println("The output for query B is\n");
		System.out.println("kursID1" + "   " + "kursID2" + "    " + "studiengangsID");

		// loop to remove results of A from B
		Iterator<QueryB> it = listB.iterator();

		for (int i = 0; i < listA.size(); i++) {

			while (it.hasNext()) {
				QueryB str = (QueryB) it.next();

				if ((listA.get(i).studiengangsID.equals(str.studiengangsID))
						&& (listA.get(i).kursID.equals(str.kursID1) || listA.get(i).kursID.equals(str.kursID2))) {
					it.remove();
				}
			}

		}

		// loop to only include one way results in Query B
		for (int i = 0; i < listB.size() - 1; i = i + 1) {

			for (int j = i + 1; j < listB.size(); j++) {

				if (listB.get(i).kursID1.equals(listB.get(j).kursID2)
						&& listB.get(i).kursID2.equals(listB.get(j).kursID1)
						&& listB.get(i).studiengangsID.equals(listB.get(j).studiengangsID)) {

					System.out.println(listB.get(i).kursID1 + "        " + listB.get(i).kursID2 + "         "
							+ listB.get(i).studiengangsID);
				}

				else
					continue;
			}
		}

		stmt.close();

	}
}
