package de.upb.STULP.json;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import de.upb.STULP.JsonParser.JsonConversion;

/**
 * This is the main class
 * @author shrey
 *
 */
public class Main {

	public static void main(String[] args) throws SQLException, IOException {

		Connection conn = null;
		Operations op = new Operations();
		Operations_pflicht opf = new Operations_pflicht();

		if (args.length != 1) {
			System.out.println("Please provide the path for input JSON file!");
			System.exit(0);
		}

		String input_file = args[0];

		try {

			conn = op.database_Connection();

			// Converting JSON file to string type
			String file_text = new String(Files.readAllBytes(Paths.get(input_file)));

			// Deserializing the JSON file
			List<Command> cmd = JsonConversion.deserialise_JSON(file_text);

			// create the tables if they do not exist
			op.create_table_Veranstaltungsplan(conn);
			opf.create_table_pflicht(conn);

			// clear the existing records from the tables
			op.clear_table_Veranstaltungsplan(conn);
			opf.clear_table_pflicht(conn);
			
			//this method drops the existing view of the table
			op.drop_view(conn);

			// checking the type of command
			for (int i = 0; i < cmd.size(); i++) {

				Cmd command;
				command = cmd.get(i).getCmd();

				switch (command) {

				case insert:
					op.insert_Veranstaltungsplan(conn, cmd.get(i).getVeranstaltungseintrag());
					break;

				case insert_pflicht:
					opf.insert_pflicht(conn, cmd.get(i).getPflichteintrag());
					break;

				default:
					System.out.println("Invalid Command!");
					break;

				}

			}

			//this method checks for the conflicts
			op.showConflict(conn);

		}catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

	}

}
