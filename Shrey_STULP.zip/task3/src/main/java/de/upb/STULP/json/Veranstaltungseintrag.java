package de.upb.STULP.json;

/**
 * This class represents a database entry. It is used by {@link Command} and
 * {@link DatabaseState}.
 *
 */
public final class Veranstaltungseintrag {

	private String raumNr, profID, kursID, veranstaltungart;
	private Tag tag;
	private int veranstaltungsteil, dauer, uhrzeit, wunschzeit;

	public Veranstaltungseintrag() {
	}

	public Veranstaltungseintrag(String raumNr, String profID, String kursID, String veranstaltungart, Tag tag,
			int veranstaltungsteil, int dauer, int startzeit, int wunschzeit) {
		this.raumNr = raumNr;
		this.profID = profID;
		this.kursID = kursID;
		this.veranstaltungart = veranstaltungart;
		this.tag = tag;
		this.veranstaltungsteil = veranstaltungsteil;
		this.dauer = dauer;
		this.uhrzeit = startzeit;
		this.wunschzeit = wunschzeit;
	}

	/**
	 * 
	 * @return wunschzeit
	 */
	public int getWunschzeit() {
		return wunschzeit;
	}

	/**
	 * 
	 * @param wunschzeit
	 */
	public void setWunschzeit(int wunschzeit) {
		this.wunschzeit = wunschzeit;
	}

	/**
	 * @return the veranstaltungsteil
	 */
	public int getVeranstaltungsteil() {
		return veranstaltungsteil;
	}

	/**
	 * @param veranstaltungsteil the veranstaltungsteil to set
	 */
	public void setVeranstaltungsteil(int veranstaltungsteil) {
		this.veranstaltungsteil = veranstaltungsteil;
	}

	/**
	 * @return the dauer
	 */
	public int getDauer() {
		return dauer;
	}

	/**
	 * @param dauer the dauer to set
	 */
	public void setDauer(int dauer) {
		this.dauer = dauer;
	}

	/**
	 * @return the startzeit
	 */
	public int getUhrzeit() {
		return uhrzeit;
	}

	/**
	 * @param uhrzeit the startzeit to set
	 */
	public void setUhrzeit(int uhrzeit) {
		this.uhrzeit = uhrzeit;
	}

	/**
	 * @return the raum
	 */
	public String getRaumNr() {
		return raumNr;
	}

	/**
	 * @param raumNr the raum to set
	 */
	public void setRaumNr(String raumNr) {
		this.raumNr = raumNr;
	}

	/**
	 * @return the profID
	 */
	public String getProfID() {
		return profID;
	}

	/**
	 * @param profID the profID to set
	 */
	public void setProfID(String profID) {
		this.profID = profID;
	}

	/**
	 * @return the kursID
	 */
	public String getKursID() {
		return kursID;
	}

	/**
	 * @param kursID the kursID to set
	 */
	public void setKursID(String kursID) {
		this.kursID = kursID;
	}

	/**
	 * @return the veranstaltungart
	 */
	public String getVeranstaltungart() {
		return veranstaltungart;
	}

	/**
	 * @param veranstaltungart the veranstaltungart to set
	 */
	public void setVeranstaltungart(String veranstaltungart) {
		this.veranstaltungart = veranstaltungart;
	}

	/**
	 * @return the tag
	 */
	public Tag getTag() {
		return tag;
	}

	/**
	 * @param tag the tag to set
	 */
	public void setTag(Tag tag) {
		this.tag = tag;
	}

}
