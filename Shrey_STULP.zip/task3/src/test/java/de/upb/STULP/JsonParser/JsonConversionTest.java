package de.upb.STULP.JsonParser;

import junit.framework.TestCase;

/**
 * simple example test for json conversion
 */
public class JsonConversionTest extends TestCase
{

    /**
     * test a round trip of Json conversion for a simple example
     */
    public void testJson()
    {
       
    
    }
}
